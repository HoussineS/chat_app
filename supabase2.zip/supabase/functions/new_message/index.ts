import { createClient } from "npm:@supabase/supabase-js@2";
import { JWT } from "npm:google-auth-library@9";
import "jsr:@supabase/functions-js/edge-runtime.d.ts";

interface Message {
  message: string;
  username: string;
  toUser: string;
  userId: string
}

interface WebhookPayload {
  type: "insert";
  table: string;
  record: Message;
  old_record: null | Message;
}

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

Deno.serve(async (req) => {
  const payload: WebhookPayload = await req.json();

  // Fetch FCM token of the receiver
  const { data, error } = await supabase
    .from("profiles")
    .select("token")
    .eq("id", payload.record.profile_id)
    .maybeSingle();

  if (error || !data?.token) {
    console.error("❌ Token fetch error", error, data);
    return new Response("Token fetch error", { status: 400 });
  }

  // Load Firebase credentials from env
  const clientEmail = Deno.env.get("FCM_CLIENT_EMAIL")!;
  const privateKey = Deno.env.get("FCM_PRIVATE_KEY")!.replace(/\\n/g, "\n");
  const projectId = Deno.env.get("FCM_PROJECT_ID")!;

  const accessToken = await getAccessToken({ clientEmail, privateKey });

  const res = await fetch(
    `https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        message: {
          token: data.token,
          notification: {
            title: "New message",
            body: `${payload.record.username}\nMessage: ${payload.record.message}`,
          },
        },
      }),
    }
  );

  const resData = await res.json();
  if (res.status < 200 || res.status > 299) {
    console.error("❌ FCM Error", resData);
    throw new Error(JSON.stringify(resData));
  }

  return new Response(JSON.stringify(resData), {
    headers: { "Content-Type": "application/json" },
  });
});

const getAccessToken = ({
  clientEmail,
  privateKey,
}: {
  clientEmail: string;
  privateKey: string;
}): Promise<string> =>
  new Promise((resolve, reject) => {
    const jwtClient = new JWT({
      email: clientEmail,
      key: privateKey,
      scopes: ["https://www.googleapis.com/auth/firebase.messaging"],
    });
    jwtClient.authorize((err, token) => {
      if (err) {
        reject(err);
        return;
      }
      resolve(token?.access_token!);
    });
  });
