import 'package:flutter/material.dart';

class Splashui extends StatelessWidget {
  const Splashui({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: const Center(child: CircularProgressIndicator()));
  }
}
