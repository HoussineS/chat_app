import 'package:chat_app/widgets/chat_bubble.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ChatMessages extends StatelessWidget {
  final String otherUserId;
  ChatMessages({super.key, required this.otherUserId});
  final user = Supabase.instance.client.auth.currentUser!;
  @override
  Widget build(BuildContext context) {
    
    return StreamBuilder(
      stream: Supabase.instance.client
          .from('messages')
          .stream(primaryKey: ['id'])
          .order('created_at', ascending: true)
          .map(
            (rows) => rows
                .where(
                  (row) =>
                      // messages sent by current user to other
                      (row['userId'] == user.id &&
                          row['toUser'] == otherUserId) ||
                      // messages received by current user from other
                      (row['userId'] == otherUserId &&
                          row['toUser'] == user.id),
                )
                .toList(),
          ),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }
        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Center(child: Text('No messaeg yet'));
        }
        if (snapshot.hasError) {
          return Center(child: Text('somthink went worong'));
        }

        final loadMessages = snapshot.data!;
        return ListView.builder(
          itemCount: loadMessages.length,
          itemBuilder: (context, index) {
            return ChatBubble(
              isMe: loadMessages[index]['userId'] == user.id,
              message: loadMessages[index]['message'],
              username: loadMessages[index]['username'],
              createdAt: DateTime.parse(loadMessages[index]['created_at']),
              imageUrl: loadMessages[index]['imageUrl'],
            );
          },
        );
      },
    );
  }
}
